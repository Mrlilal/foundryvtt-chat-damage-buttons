# foundryvtt-chat-damage-buttons
This module was taken from hooking's Gitlab and fixed with p4535992's merge request fix.
